# Dayanne Mary — layout original + melhorias funcionais (4.0 RC1)

**Importante:** esta versão ainda é **candidata para homologação**. O aplicativo original `https://dayanne-mary.netlify.app` **não foi alterado**. Não divulgar a nova página para clientes sem concluir os testes de integração reais.

## O que foi preservado

- HTML original de `MeuAppAgendamento(2).zip`, inclusive cabeçalho, tipografia, cores, logo e todos os componentes originais. Testes automatizados verificam o hash exato do cabeçalho e CSS original.
- Calendário, bloqueio por manhã/tarde/dia inteiro, WhatsApp, visões de agenda, reagendamento e confirmação; adicionadas adaptações de segurança ao armazenamento.
- Horário **original**: terça a sexta 9h–18h, sábado 9h–15h. Restrição original de sextas-feiras até 27/11/2026 também foi mantida.

## Melhorias implementadas

1. Seleção de **até cinco serviços** numa mesma reserva; duração total bloqueada como um período único.
2. Tabela de preços com desconto nos mesmos cards (valor anterior riscado), preço normal, preço final e desconto no resumo.
3. Campanha Black Friday padrão de **25% de 01 a 30/11/2026**, editável pelo administrador; criação de campanhas de até 90% (incluindo 50%), datas e serviços participantes. Campanhas não se acumulam: vale a maior promoção por serviço.
4. Painel Promoções: criar, editar, desativar e excluir, sem alterar o HTML.
5. Painel Serviços: adicionar, alterar nome, preço e duração, ativar/desativar, cadastrar URL HTTPS de fotografia opcional.
6. Painel Agenda: agendamento manual, fora do horário comercial pela administradora, bloqueios originais, cancelamento, reagendamento e status concluído.
7. Painel Horários: configurar abertura e fechamento por dia.
8. Indicadores de reservas, atendimentos, serviços, previsão, realizado e cancelamentos.
9. Backend com Netlify Functions + Firebase Admin SDK; regras do Firestore não precisam permitir acesso público às coleções novas.
10. Firebase Authentication para o admin; **a senha fixa do HTML foi removida**.
11. Reserva pública processada em transação e com limites por IP e telefone. Token individual guardado pelo navegador permite cancelamento/reagendamento da nova reserva sem expor registros de outras clientes.

## Isolamento obrigatório

- Site antigo: `dayanne-mary.netlify.app` (**não publicar nesta URL**).
- Site de teste: `dayanne-mary-beautystudio.netlify.app`.
- Projeto Firebase de autenticação: `dayanne-mary` (dados web públicos já presentes na configuração original do app).
- **Coleções novas**: `dm_bs_agendamentos`, `dm_bs_bloqueios`, `dm_bs_campanhas`, `dm_bs_servicos`, `dm_bs_days`, `dm_bs_rate`, `dm_bs_config`.
- **Coleção antiga `agendamentos` é apenas lida pelo servidor** para reconhecer horários ocupados e mostrar reservas antigas no painel (somente leitura). O app novo **não escreve, altera ou exclui registros antigos**.
- A sobreposição entre sites novos e antigos não pode ser eliminada completamente enquanto ambos continuarem recebendo agendamentos: o site legado ainda grava sem participar da transação do novo site. **Antes da divulgação final, é necessário migrar/desativar as reservas públicas do legado ou unificar o mecanismo de gravação.**

## Publicar somente no projeto de TESTE via painel, sem Terminal

**Forma recomendada:** criar um repositório no GitHub contendo o conteúdo desta pasta (com `package.json`, `netlify.toml`, `public`, `netlify/functions`, `shared`). Na Netlify:

1. Abra o projeto existente **dayanne-mary-beautystudio** (não crie outro e não abra o projeto original).
2. Entre em **Project configuration → Developer settings → Continuous deployment → Repository → Link repository**.
3. Escolha o repositório desta versão. A publicação automática do Netlify fará o build e detectará a função `api`.
4. Confirme que a publicação **Publish directory** está como `public` e o caminho da Function é `netlify/functions` (definidos em `netlify.toml`).
5. Confira as variáveis de ambiente, já cadastradas anteriormente no projeto de teste:
   - `FIREBASE_SERVICE_ACCOUNT_B64`: chave privada do Firebase Admin em base64 (segredo **somente nas configurações da Netlify**, nunca no repositório).
   - `ADMIN_UID`: UID da conta administradora criada no Firebase Authentication.
   - `FIREBASE_WEB_API_KEY`: pode permanecer cadastrada, mas não é usada pelo servidor nesta edição.
6. Verifique o relatório de deploy e os logs da função `api`. Se a função não for publicada, não teste reservas: a página isolada não conseguirá gravar no Firebase.

**Observação:** drag-and-drop estático apenas da pasta `public` **não serve**, pois não publica a função de agendamento. Se optar pelo Netlify Drop, envie o projeto completo em sessão autenticada e confirme que ele reconheceu e compilou `netlify/functions`; o Git é o método mais previsível.

## Checklist de homologação obrigatória

- [ ] Deploy e empacotamento da função `api` sem erros.
- [ ] `GET https://dayanne-mary-beautystudio.netlify.app/api?resource=beautyStudioCampanhas` devolve JSON com a promoção ativa, **sem dados pessoais**.
- [ ] Criar reserva de 1 serviço; confirmar cadastro em `dm_bs_agendamentos` e bloqueio do intervalo.
- [ ] Criar reserva de 3 serviços; conferir preço/duração no resumo e no painel.
- [ ] Criar concorrência de dois agendamentos para a mesma hora; somente um deve ser aceito.
- [ ] Testar reagendamento com token e cancelamento; verificar liberação do horário.
- [ ] Logar admin com e-mail/senha; verificar que UID não autorizado é rejeitado.
- [ ] Editar Black Friday de 25% para 50%, depois desativar e verificar preços.
- [ ] Criar e bloquear dias e horários, criar encaixe admin à noite.
- [ ] Marcar atendimento concluído e conferir faturamento realizado.
- [ ] Confirmar que as reservas originais não foram alteradas e o site antigo continua operando.
- [ ] Resolver convivência das duas agendas ANTES de divulgar ambos.

## Testes locais realizados

`npm test` — testes de soma, desconto, sobreposição, fechamento e hashes CSS/cabeçalho passaram. `node --check` da função e da interface também passou. **Não foi possível concluir a instalação das dependências neste ambiente; o build Netlify e o Firebase real não foram verificados.** Não considerar o aplicativo pronto para clientes antes da checklist.

## Observação urgente sobre o site antigo

A regra temporária anteriormente usada para recuperar `dayanne-mary.netlify.app` expira em **08/11/2026 00:00 UTC (07/11/2026 às 21h, Brasília)**. Isso pode voltar a interromper os agendamentos antigos. Corrigir o backend do antigo ou concluir uma migração segura antes da expiração; não deixar regras públicas irrestritas de leitura e gravação.
